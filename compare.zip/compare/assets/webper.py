import os
# os.system("cwebp -preset photo .\customOverlay\health.png -o .\customOverlay\health.webp")
subdirs = [x[0] for x in os.walk(".")]
print(subdirs)
for subdir in subdirs:
    for (root, dirs, files) in os.walk(subdir):
        if len(files) > 0:
            for file in files:
                if file.endswith(".png"):
                    filename = file.split(".png")[0]
                    os.system(f"cwebp -preset photo {file} -o {subdir}{filename}.webp")
        print("------------------")